
# Hiver SDE Intern — Decision Log

1. No OpenAI API is used.

2. The solution runs locally.

3. All usable records are used as the retrieval knowledge base.

4. Empty messages are removed.

5. Duplicate messages are removed.

6. TF-IDF + Logistic Regression is used as the main
   supervised baseline when intent labels are available.

7. Majority class is used as a simple baseline.

8. Cosine similarity is used for historical retrieval.

9. Multiple historical examples are retrieved.

10. Historical responses are reused only when sufficient
    evidence exists.

11. Safe response templates are used when historical
    responses are unavailable.

12. Low-confidence predictions are escalated.

13. Weak retrieval is escalated.

14. Unknown intents are escalated.

15. A 200-example golden-set template is created.

16. Golden-set labels must be manually verified.

17. Intent accuracy is not treated as the only quality metric.

18. Failure analysis is included.

19. API keys and secrets are excluded from the repository.
