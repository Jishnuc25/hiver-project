
# Hiver SDE Intern Assignment
# AI Customer Support Agent

## Project

This project implements a local AI customer-support
agent without using the OpenAI API.

## Important

NO API KEY IS REQUIRED.

NO OPENAI API IS USED.

The system runs locally using:

- Python
- Pandas
- Scikit-learn
- TF-IDF
- Logistic Regression
- Cosine Similarity
- Rule-based safe response generation

---

# Pipeline

Customer Message
        |
        v
Data Cleaning
        |
        v
Intent Classification
        |
        v
Historical Retrieval
        |
        v
Relevant Past Cases
        |
        v
Reply Generation
        |
        v
Confidence + Evidence
        |
        v
AUTO-HANDLE / ESCALATE

---

# Dataset

Dataset:
amazon_product.csv

Selected Brand:
False

Usable Records:
40

---

# Intent Categories

- refund
- payment_problem
- account_problem
- login_problem
- delivery_problem
- cancellation
- subscription
- technical_issue
- product_problem
- complaint
- information_request
- other

---

# Intent Model

The primary local classifier is:

TF-IDF + Logistic Regression

Baselines include:

1. Majority Class
2. TF-IDF + Logistic Regression

---

# Historical Retrieval

The system uses all usable records as a historical
knowledge base.

TF-IDF is used to represent customer messages.

Cosine similarity is used to retrieve similar cases.

---

# Reply Generation

Responses are generated locally.

If a historical response exists and similarity is
strong enough, the historical response can be reused.

Otherwise, a safe intent-based response template is used.

The system does not invent:

- Refund amounts
- Delivery dates
- Discounts
- Company policies
- Compensation
- Completed actions

---

# Auto Handle / Escalate

The system escalates when:

- Confidence < 0.60
- Historical evidence is missing
- Similarity is weak
- Intent is unknown
- No strong historical response is available

---

# Golden Set

A 200-example golden-set template is created.

Human labelling is required for:

- true_intent
- expected_handling
- expected_reply

The golden set should be manually reviewed before
final evaluation.

---

# Evaluation


Supervised intent metrics are not available because
the uploaded dataset does not contain sufficient
ground-truth intent labels.


Additional evaluation:

- Retrieval similarity
- Confidence
- Auto-handle rate
- Escalation rate
- Grounding
- Failure analysis

---

# Failure Analysis

The main failure modes considered are:

1. Low intent confidence
2. Weak retrieval
3. Missing historical response
4. Ambiguous messages
5. Unknown intent

---

# Misleading Headline Number

Classification accuracy alone is not sufficient to
measure an AI support agent.

A classifier can correctly identify an intent while
still producing an unsuitable support response.

Therefore this project considers:

- Intent accuracy
- Retrieval quality
- Evidence
- Reply grounding
- Escalation
- Failure modes

---

# Future Improvements

- Sentence embeddings
- Hybrid retrieval
- Semantic search
- Better intent taxonomy
- Multi-intent classification
- More human-labelled data
- LLM-as-judge
- Human agreement
- Confidence calibration

---

# API KEY

No OpenAI API key is required.

No secret key is stored in this project.

---

# Run

Install dependencies:

pip install -r requirements.txt

Then run the notebook/script.

